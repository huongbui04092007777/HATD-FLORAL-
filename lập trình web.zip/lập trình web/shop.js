// script.js

function changeImage(smallImg) {
    const mainImg = document.getElementById('MainImg');
    mainImg.src = smallImg.src;
}
console.log("JavaScript đã hoạt động!");

