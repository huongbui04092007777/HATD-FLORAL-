document.addEventListener("DOMContentLoaded", function () {
    const numFlowers = 30; // Số lượng cánh hoa
    const body = document.body;

    for (let i = 0; i < numFlowers; i++) {
        let flower = document.createElement("div");
        flower.classList.add("flower");

        // Vị trí ngẫu nhiên cả theo chiều ngang (left) và chiều dọc (top)
        flower.style.left = Math.random() * 100 + "vw"; // Trải rộng toàn màn hình
        flower.style.top = Math.random() * 100 + "vh"; // Hoa xuất hiện ngẫu nhiên từ trên xuống dưới

        // Thời gian rơi ngẫu nhiên
        let duration = Math.random() * 5 + 3; // 3-8 giây
        flower.style.animationDuration = duration + "s";

        // Thêm vào trang
        body.appendChild(flower);
    }
});





document.addEventListener("DOMContentLoaded", function () {
    let currentIndex = 0; // Chỉ số ảnh đang hiển thị
    const images = document.querySelectorAll(".team-container img");
    const prevButton = document.querySelector(".arrow.left");
    const nextButton = document.querySelector(".arrow.right");

    if (images.length === 0) {
        console.error("Không tìm thấy ảnh trong .team-container");
        return;
    }

    function updateSlider() {
        images.forEach((img, index) => {
            img.style.display = index === currentIndex ? "block" : "none";
        });
    }

    nextButton.addEventListener("click", function () {
        currentIndex = (currentIndex + 1) % images.length;
        updateSlider();
    });

    prevButton.addEventListener("click", function () {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        updateSlider();
    });

    updateSlider(); // Hiển thị ảnh đầu tiên khi load trang
});





document.addEventListener("DOMContentLoaded", function () {
    loadCart();

    // Bắt sự kiện click cho nút "Thêm vào giỏ hàng"
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", function (event) {
            event.preventDefault();  // Ngăn reload trang (nếu có)
            event.stopImmediatePropagation(); // Ngăn chặn sự kiện click bị gọi nhiều lần

            const product = {
                id: this.dataset.id,
                name: this.dataset.name,
                price: this.dataset.price,
                image: this.dataset.image,
                quantity: 1
            };

            let cart = JSON.parse(localStorage.getItem("cart")) || [];

            // Kiểm tra nếu sản phẩm đã có trong giỏ hàng thì tăng số lượng, nếu chưa thì thêm mới
            let existingProduct = cart.find(item => item.id === product.id);
            if (existingProduct) {
                existingProduct.quantity += 1;
            } else {
                cart.push(product);
            }

            localStorage.setItem("cart", JSON.stringify(cart));

            // Hiển thị thông báo
            showNotification(`${product.name} đã thêm vào giỏ hàng!`);

            loadCart(); // Cập nhật giỏ hàng ngay lập tức
        }, { once: true }); // Chỉ gán sự kiện 1 lần cho mỗi button
    });

    // Bắt sự kiện nút "Xóa giỏ hàng"
    const clearCartBtn = document.getElementById("clear-cart");
    if (clearCartBtn) {
        clearCartBtn.addEventListener("click", function () {
            localStorage.removeItem("cart");
            loadCart();
        });
    }
});

// Hàm hiển thị thông báo
function showNotification(message) {
    let notification = document.createElement("div");
    notification.innerText = message;
    notification.style.position = "fixed";
    notification.style.bottom = "20px";
    notification.style.right = "20px";
    notification.style.background = "#4CAF50";
    notification.style.color = "white";
    notification.style.padding = "10px 20px";
    notification.style.borderRadius = "5px";
    notification.style.boxShadow = "0 2px 10px rgba(0, 0, 0, 0.2)";
    notification.style.zIndex = "1000";

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 2000);
}

// Hàm tải giỏ hàng vào cart.html
function loadCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartContainer = document.getElementById("cart-items");

    if (!cartContainer) return; // Kiểm tra nếu không có cart.html thì không làm gì cả

    cartContainer.innerHTML = "";

    cart.forEach(item => {
        let cartItem = document.createElement("div");
        cartItem.classList.add("cart-item");
        cartItem.innerHTML = `
            <img src="${item.image}" alt="${item.name}" style="width: 100px; height: 100px;">
            <div>
                <h3>${item.name}</h3>
                <p>Giá: ${parseInt(item.price).toLocaleString()} VND</p>
                <p>Số lượng: <input type="number" value="${item.quantity}" min="1" onchange="updateQuantity('${item.id}', this.value)"></p>
            </div>
            <button onclick="removeFromCart('${item.id}')">Xóa</button>
        `;
        cartContainer.appendChild(cartItem);
    });
}

// Hàm cập nhật số lượng sản phẩm
function updateQuantity(id, quantity) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let product = cart.find(item => item.id === id);

    if (product) {
        product.quantity = parseInt(quantity);
        localStorage.setItem("cart", JSON.stringify(cart));
        loadCart();
    }
}

// Hàm xóa sản phẩm khỏi giỏ hàng
function removeFromCart(id) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart = cart.filter(item => item.id !== id);
    localStorage.setItem("cart", JSON.stringify(cart));
    loadCart();
}
